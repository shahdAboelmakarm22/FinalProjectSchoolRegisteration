module com.example.Schoolregisterationproject {

    requires javafx.fxml;
    requires java.datatransfer;
    requires java.desktop;
    requires java.sql;
    requires org.mongodb.driver.core;
    requires org.mongodb.bson;
    requires org.mongodb.driver.sync.client;
    requires java.management;
    requires javafx.graphics;
    requires javafx.controls;


    opens com.example.schoolregisterationproject to javafx.fxml;
    exports com.example.schoolregisterationproject;

}