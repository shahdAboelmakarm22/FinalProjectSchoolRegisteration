package com.example.schoolregisterationproject;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.fxml.FXML;
//import javafx. scene. control. ButtonBase;

//import java.awt.event.MouseEvent;
import java.io.IOException;

import javafx.scene.control.TextField;

import javafx.scene.Node;
public class StudentUpdateController {
    @FXML
    Button updatebtn;
    @FXML
       TextField firstname;
    @FXML
            TextField lastname;
    @FXML
            TextField email;
    @FXML
            TextField phonenumb;
    @FXML
            TextField address;
    @FXML
            TextField password;
    Student student;
    @FXML
    private void initialize() {
        // Initialize the updatebtn object here
        updatebtn.setText("Update Info");
        // Add an event handler to the updatebtn object
        updatebtn.setOnAction(this::handleUpdateInfoAction);
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public TextField getFirstname() {
        return firstname;
    }
    public void setFirstname(TextField firstname) {
        this.firstname = firstname;
    }

    public TextField getAddress() {
        return address;
    }
    public void setAddress(TextField address) {this.address=address;}
    public TextField getEmail() {return email;}
    public void setEmail(TextField email) {this.email=email;}
    public TextField getPhonenumb() {return phonenumb;}

    public void setPhonenumb(TextField phonenumb) {
        this.phonenumb = phonenumb;
    }
    public TextField getPassword() {return password;}
    public void setPassword(TextField password) { this.password = password;}


    @FXML
    private void handleUpdateInfoAction(ActionEvent event) {
        // Check if the student object is initialized
        if (student == null) {
            // Display an error message or handle the error condition
            return; 
        }

        // Get the text from the TextField objects
        String firstName = firstname.getText();
        String lastName = lastname.getText();
        String emailText = email.getText();
        String phoneNumber = phonenumb.getText();
        String addressText = address.getText();

        // Update the student's information
        student.updateinformation(firstName, lastName, emailText, phoneNumber, addressText);
    }
}
