package com.example.schoolregisterationproject;
import java.util.*;
public class Student extends Person {
    private static List<Grade> grades;
    private static List<Course> courses = new ArrayList<>();
    private Teacher teacher;
    private int StudentId;
    private int credithours;

    public int getStudentId() {
        return StudentId;
    }
    public void setStudentId(int studentId) {
        StudentId = studentId;
    }
    private double gpa;
    public double getGpa() {
        return gpa;
    }
    public Student(String firstName, String lastName, String email, String phoneNumber, String address, String level,String password) {
        super(firstName, lastName, email, phoneNumber, address, level,password);
    }
    public Student(String firstName, String lastName, String email, String phoneNumber, String address, String level,String password,int StudentId,int gpa,List<Grade> grades) {
        super(firstName, lastName, email, phoneNumber, address, level,password);
        this.StudentId= StudentId;
        this.gpa = gpa;
        this.grades = grades;
    }
    public Student(List<Grade> grades, Teacher teacher, int StudentId, int credithours, int gpa) {
        this.grades = grades;
        this.teacher = teacher;
        this.StudentId = StudentId;
        this.credithours=credithours;
        this.gpa=gpa;

    }
    public static List<Course> getCourses() {
        return courses;
    }
    public List<Grade> getGrades() {
        return grades;
    }
    public void setGrades(List<Grade> grades) {
        Student.grades = grades;
    }
    public int getCredithours() {
        return credithours;
    }
    public void updateinformation(String firstName, String lastName, String email, String phoneNumber, String address) {
        try {
            if (firstName == null || firstName.isEmpty()) {
                throw new IllegalArgumentException("firstName cannot be null or empty");
            }
            setFirstName(firstName);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (lastName == null || lastName.isEmpty()) {
                throw new IllegalArgumentException("lastName cannot be null or empty");
            }
            setLastName(lastName);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (email == null || email.isEmpty()) {
                throw new IllegalArgumentException("email cannot be null or empty");
            }
            setEmail(email);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (phoneNumber == null || phoneNumber.isEmpty()) {
                throw new IllegalArgumentException("phoneNumber cannot be null or empty");
            }
            setPhoneNumber(phoneNumber);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (address == null || address.isEmpty()) {
                throw new IllegalArgumentException("address cannot be null or empty");
            }
            setAddress(address);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
    }
    public String getRole(String Studentlevel) {
        if (Studentlevel == null || Studentlevel.isEmpty()) {
            throw new IllegalArgumentException("level cannot be null or empty");
        }
        else if (Studentlevel.equals("elementary"))
        {return "Elementary School Student";
        }
        else if (Studentlevel.equals("middle"))
        {return "Middle School Student";
        }
        else if (Studentlevel.equals("high"))
        {
            return "High School Student";
        }
        else if (Studentlevel.equals("graduate"))
        {
            return "Graduate Student";
        }
        else
            return null;
    }
    public static boolean isEnrolledInCourse(Course course, Student student) {
        try {
            if (student != null && course != null) {
                boolean enrolled = student.getCourses().contains(course);
                System.out.println("Student ID: " + student.getStudentId() + " is enrolled in course: " + enrolled);
                return enrolled;
            } else {
                System.out.println("Student or course is null.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error occurred while checking enrollment status: " + e.getMessage());
            return false;
        }
    }
    public void viewgrades() {
        if (grades != null) {
            System.out.println("Grades for " + getFirstName() + " " + getLastName() + ":");
            for (Grade grade : grades) {
                Course course = grade.getCourse();
                if (course != null) {
                    System.out.println("Course: " + course.getCourseName()+ ", Grade: " + grade.getGrade());
                } else {
                    System.out.println("Course: [Unknown], Grade: " + grade.getGrade());
                }
            }
        } else {
            System.out.println("No grades available for " + getFirstName() + " " + getLastName());
        }
    }
    public void bookTicket(int studentId, Transportation transportation) {
        if (transportation.isTicket()) {
            System.out.println("Ticket already booked for transportation of Student " + studentId + ".");
        } else {
            transportation.setTicket(true);
            System.out.println("Ticket booked successfully for transportation of Student " + studentId + ".");
        }
    }
    public String toString() {
        String info = "Student Information:\n";
        info += "Name: " + getFirstName() + " " + getLastName() + "\n";
        info += "Student ID: " + StudentId + "\n";
        info += "GPA: " + gpa + "\n";
        info += "Credit Hours: " + credithours + "\n";
        return info;
    }

}

