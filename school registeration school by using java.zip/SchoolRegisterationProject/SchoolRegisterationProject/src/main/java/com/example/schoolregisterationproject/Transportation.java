package com.example.schoolregisterationproject;
import java.util.ArrayList;
import java.util.List;
public class Transportation {
    private Student student;
    private Teacher teacher;
    private boolean ticket;
    private int TransportationId;
    private int availableSeats;
    private List<Student> studentList;
    private List<Teacher> teacherList;
    public Transportation(Student student, Teacher teacher, boolean ticket) {
        this.student = student;
        this.teacher = teacher;
        this.ticket = ticket;
        this.studentList = new ArrayList<>();
        this.teacherList = new ArrayList<>();
    }
    public Transportation(Student student, Teacher teacher, int transportationId) {
        this.student = student;
        this.teacher = teacher;
        TransportationId = transportationId;
    }
    public Transportation(int transportationId, int availableSeats) {
        this.TransportationId = transportationId;
        this.availableSeats = availableSeats;
        this.ticket = false;
    }
    public int getAvailableSeats() {
        return availableSeats;
    }
    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }
    public Student getStudent() {
        return student;
    }
    public int getTransportationId() {
        return TransportationId;
    }
    public void setTransportationId(int transportationId) {
        TransportationId = transportationId;
    }
    public List<Student> getStudentList() {
        return studentList;
    }
    public void setStudentList(List<Student> studentList) {
        this.studentList = studentList;
    }
    public List<Teacher> getTeacherList() {
        return teacherList;
    }
    public void setTeacherList(List<Teacher> teacherList) {
        this.teacherList = teacherList;
    }
    public void setStudent(Student student) {
        this.student = student;
    }
    public Teacher getTeacher() {
        return teacher;
    }
    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }
    public boolean isTicket() {
        return ticket;
    }
    public void setTicket(boolean ticket) {
        this.ticket = ticket;
    }
    public void calculateCapacity() {
        int capacity = studentList.size() + teacherList.size();
        System.out.println("Total Capacity: " + capacity);
    }
    public void recordAttendance() {
        if (student != null) {
            if (studentList == null) {
                studentList = new ArrayList<>();
            }
            if (!studentList.contains(student)) {
                studentList.add(student);
            }
        }
        if (teacher != null) {
            if (teacherList == null) {
                teacherList = new ArrayList<>();
            }
            if (!teacherList.contains(teacher)) {
                teacherList.add(teacher);
            }
        }
    }
    public void addPassenger(int transportationId, Student student) {
        try {
            if (!studentList.contains(student)) {
                studentList.add(student);
                System.out.println("Student added to transportation with ID: " + transportationId);
            } else {
                System.out.println("Student is already added to transportation with ID: " + transportationId);
            }
        } catch (Exception e) {
            System.out.println("Error occurred while adding student to transportation: " + e.getMessage());
        }
    }
    public void addPassenger(int transportationId, Teacher teacher) {
        try {
            if (!teacherList.contains(teacher)) {
                teacherList.add(teacher);
                System.out.println("Teacher added to transportation with ID: " + transportationId);
            } else {
                System.out.println("Teacher is already added to transportation with ID: " + transportationId);
            }
        } catch (Exception e) {
            System.out.println("Error occurred while adding teacher to transportation: " + e.getMessage());
        }
    }
    public void removePassenger(int transportationId, Student student) {
        try {
            if (studentList.contains(student)) {
                studentList.remove(student);
                System.out.println("Student removed from transportation with ID: " + transportationId);
            } else {
                System.out.println("Student is not in transportation with ID: " + transportationId);
            }
        } catch (Exception e) {
            System.out.println("Error occurred while removing student from transportation: " + e.getMessage());
        }
    }
    public void removePassenger(int transportationId, Teacher teacher) {
        try {
            if (teacherList.contains(teacher)) {
                teacherList.remove(teacher);
                System.out.println("Teacher removed from transportation with ID: " + transportationId);
            } else {
                System.out.println("Teacher is not in transportation with ID: " + transportationId);
            }
        } catch (Exception e) {
            System.out.println("Error occurred while removing teacher from transportation: " + e.getMessage());
        }
    }
    public String toString() {
        String info = "Transportation Information:\n";
        info += "Student: " + (student != null ? student.getFirstName() + " " + student.getLastName() : "None") + "\n";
        info += "Teacher: " + (teacher != null ? teacher.getFirstName() + " " + teacher.getLastName() : "None") + "\n";
        info += "Ticket: " + (ticket ? "Booked" : "Not Booked") + "\n";
        info += "Total Students: " + studentList.size() + "\n";
        info += "Total Teachers: " + teacherList.size() + "\n";

        return info;
    }
    public void bookTicket() {
        if (!ticket && availableSeats > 0) {
            ticket = true;
            availableSeats--;
            System.out.println("Ticket booked successfully. Available seats: " + availableSeats);
        } else if (ticket) {
            System.out.println("Ticket already booked.");
        } else {
            System.out.println("No available seats.");
        }
    }

}
