package com.example.schoolregisterationproject;
public class Parent extends Person {
    private Student student;
    public Parent(String firstName, String lastName, String email, String phoneNumber, String address, String level, Student student,String password) {
        super(firstName, lastName, email, phoneNumber, address, level,password);
        this.student = student;
    }
    public Student getStudent() {
        return student;
    }
    public void setStudent(Student student) {
        this.student = student;
    }
    public void updateinformation(String firstName, String lastName, String email, String phoneNumber, String address) {
        try {
            if (firstName == null || firstName.isEmpty()) {
                throw new IllegalArgumentException("firstName cannot be null or empty");
            }
            setFirstName(firstName);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (lastName == null || lastName.isEmpty()) {
                throw new IllegalArgumentException("lastName cannot be null or empty");
            }
            setLastName(lastName);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (email == null || email.isEmpty()) {
                throw new IllegalArgumentException("email cannot be null or empty");
            }
            setEmail(email);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (phoneNumber == null || phoneNumber.isEmpty()) {
                throw new IllegalArgumentException("phoneNumber cannot be null or empty");
            }
            setPhoneNumber(phoneNumber);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (address == null || address.isEmpty()) {
                throw new IllegalArgumentException("address cannot be null or empty");
            }
            setAddress(address);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }

    }
    public String getRole(String level) {
        return "Parent";
    }
    public void bookStudentTransportation(Student student,Transportation transportation) {
        student.bookTicket(student.getStudentId(), transportation);
    }
    public String getStudentParentName() {
        return getFirstName() + " " + getLastName();
    }
    public String toString() {
        String info = "Parent Information:\n";
        info += "Name: " + getFirstName() + " " + getLastName() + "\n";
        info += "Email: " + getEmail() + "\n";
        info += "Phone Number: " + getPhoneNumber() + "\n";
        info += "Address: " + getAddress() + "\n";
        info += "Level: " + getLevel() + "\n";
        info += "Student's Name: " + student.getFirstName() + " " + student.getLastName() + "\n";
        // Include more details as needed
        return info;
    }
}