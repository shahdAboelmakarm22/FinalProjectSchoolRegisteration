package com.example.schoolregisterationproject;
import java.util.List;
public interface ISchedule {
    List<Course> getCourses();
    void setCourses(List<Course> courses);
    String[] getDays();
    int getBreakPeriod();
    int[] getPeriods();
    String[] getCourseNames();
    String[] getCourseCodes();
}
