package com.example.schoolregisterationproject;

import java.util.ArrayList;
import java.util.List;
public class Schedule implements ISchedule {
    private static Schedule instance;
    private final String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"};
    private final int breakPeriod = 5;
    private final int[] periods = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    private final String[] courseNames = {"English", "Arabic", "Math", "History", "Geography", "Science", "Art", "Music", "Physical Education", "Computer Science"};
    private final String[] courseCodes = {"E586", "A5263", "M5394", "H3816", "G6553", "S5432", "A5678", "M5987", "PE567", "CS987"};
    private Schedule() {
        // Private constructor to prevent instantiation
    }
    public static Schedule getInstance() {
        if (instance == null) {
            instance = new Schedule();
        }
        return instance;
    }
    @Override
    public List<Course> getCourses() {
        // Implementation to retrieve courses
        return new ArrayList<>();
    }
    @Override
    public void setCourses(List<Course> courses) {
        // Implementation to set courses
    }
    @Override
    public String[] getDays() {
        return days;
    }
    @Override
    public int getBreakPeriod() {
        return breakPeriod;
    }
    @Override
    public int[] getPeriods() {
        return periods;
    }
    @Override
    public String[] getCourseNames() {
        return courseNames;
    }
    @Override
    public String[] getCourseCodes() {
        return courseCodes;
    }
}

