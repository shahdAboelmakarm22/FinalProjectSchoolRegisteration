package com.example.schoolregisterationproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.scene.Parent;
import javafx.scene.Node;
import java.util.ArrayList;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Main page");
        stage.setScene(scene);
        stage.show();
        /*Student student1 = new Student("Alice", "Smith", "alice.smith@example.com", "111111111", "111 Main St", "high");
        Student student2 = new Student("Bob", "Johnson", "bob.johnson@example.com", "222222222", "222 Oak St", "middle");
        Student student3 = new Student("Charlie", "Brown", "charlie.brown@example.com", "333333333", "333 Elm St", "high");
        Student student4 = new Student("Diana", "Williams", "diana.williams@example.com", "444444444", "444 Pine St", "elementary");
        Student student5 = new Student("Eva", "Davis", "eva.davis@example.com", "555555555", "555 Maple St", "middle");
*/

    }



    public static void main(String[] args) {
        launch(args);
    }

}