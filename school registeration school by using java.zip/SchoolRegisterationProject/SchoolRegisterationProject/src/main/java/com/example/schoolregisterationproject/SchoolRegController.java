package com.example.schoolregisterationproject;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.FXML;
//import javafx. scene. control. ButtonBase;

//import java.awt.event.MouseEvent;
import java.io.IOException;

import javafx.scene.Node;
import org.bson.Document;

import static com.example.schoolregisterationproject.MongoDbConnection.studentCol;



public class SchoolRegController {
    @FXML
    private TextField firstnamefield;
    @FXML
    private TextField lastnamefield;
    @FXML
    private TextField emailfield;
    @FXML
    private TextField phonenumfield;
    @FXML
    private TextField addressfield;
    @FXML
    private TextField levelfield;
    @FXML
    private TextField passwordfield;
    @FXML
    Button backbtn;
    @FXML
    private Label errorlabel;
    public void registerStudent(ActionEvent event){
        try{
        long count = studentCol.countDocuments();
        int nextId = (int) (count + 1);
        Student student = new Student(String.valueOf(firstnamefield.getText()),lastnamefield.getText(),emailfield.getText(),phonenumfield.getText(),addressfield.getText(),levelfield.getText(),passwordfield.getText(),nextId,4,null);
        System.out.println(passwordfield.getText());
        MongoDbConnection.addStudent(student);
       }
        catch(Exception e){//errorlabel.setText("Invalid credintials, try again...");
    }

    }
    public void GoToStudent(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Student.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
        stage.setTitle("Student form");
        stage.show();
    }
}
