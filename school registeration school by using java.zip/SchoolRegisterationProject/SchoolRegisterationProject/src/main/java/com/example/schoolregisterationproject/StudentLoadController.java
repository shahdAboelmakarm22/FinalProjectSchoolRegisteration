package com.example.schoolregisterationproject;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.fxml.FXML;
//import javafx. scene. control. ButtonBase;

//import java.awt.event.MouseEvent;
import java.io.IOException;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import javafx.scene.Node;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Objects;

public class StudentLoadController {

    @FXML
    Button backbtn;
    @FXML
    Button SignBtn;
    @FXML
    private TextField emailfield;
    @FXML
    private TextField passfield;
    @FXML
    private Label errorlabel;


    public void GoToStudent(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Student.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
        stage.setTitle("Student form");
        stage.show();
    }
    public void login(ActionEvent event) throws IOException {
        Document userData = MongoDbConnection.loadstudent(emailfield.getText());
        if (userData != null) {
            if(Objects.equals(userData.getString("password"), passfield.getText())) {
                errorlabel.setText("Login successful!");
                GoToStudentHome(event);
    }}}

    public void GoToStudentHome(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("StudentHome.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
        stage.setTitle("Student Home form");
        stage.show();
    }

}
