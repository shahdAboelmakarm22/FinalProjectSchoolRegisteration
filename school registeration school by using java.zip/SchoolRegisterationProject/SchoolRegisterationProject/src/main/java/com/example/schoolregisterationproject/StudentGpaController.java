package com.example.schoolregisterationproject;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.fxml.FXML;
//import javafx. scene. control. ButtonBase;

//import java.awt.event.MouseEvent;
import java.io.IOException;

import javafx.scene.control.TextField;

import javafx.scene.Node;

public class StudentGpaController {

 @FXML
 Button Calcbtn;
  @FXML
 TextField TextCalc;
  @FXML
  TextField TextID;
  public Grade grade;
  public Student student;

    public Student getStudent() {
        return student;
    }


    @FXML
    private void handleCalculateButtonAction(ActionEvent event) {
        if (student != null && grade != null) {
            double gpa = Grade.totalcalculateGPA(student);
            TextCalc.setText(String.valueOf(gpa));
        }
}}
