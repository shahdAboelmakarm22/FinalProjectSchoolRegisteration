package com.example.schoolregisterationproject;

import com.mongodb.MongoWriteException;
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import org.bson.Document;
import org.bson.types.Binary;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.regex.Pattern;

import static java.lang.Thread.sleep;
import static javax.management.Query.eq;

public class MongoDbConnection {
    private static String connectionString = "mongodb+srv://abdullahaa03:attia@school.4i47y1l.mongodb.net/?retryWrites=true&w=majority&appName=School";
    private static MongoClient client = MongoClients.create(connectionString);
    private static MongoDatabase db = client.getDatabase("People");
    static MongoCollection studentCol = db.getCollection("students");

    public static void addStudent(Student student){
        Document newStudent = new Document("_id",student.getStudentId()).append("firstName",student.getFirstName()).append("lastName",student.getLastName()).append("email",student.getEmail()).append("PhoneNum",student.getPhoneNumber()).append("Address",student.getAddress()).append("level",student.getLevel()).append("password",student.getPassword()).append("GPA",student.getGpa()).append("Courses",null).append("Grades",null);
        studentCol.insertOne(newStudent);
    }
    public static Document loadstudent(String email) {
        Document query = new Document("email", email);
        Document userDocument = (Document) studentCol.find(query).first();
        return userDocument;
    }
    public static Document loadstudent(int id) {
        Document query = new Document("_id", id);
        Document userDocument = (Document) studentCol.find(query).first();
        return userDocument;
    }
    public static void updateStudent(String id, Document userData) {
        MongoCollection<Document> collection = studentCol;
        collection.updateOne(new Document("email", id), new Document("$set", userData));
    }
}
