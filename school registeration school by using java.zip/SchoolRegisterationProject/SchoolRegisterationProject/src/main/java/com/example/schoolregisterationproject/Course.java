package com.example.schoolregisterationproject;

import java.util.List;
public class Course  {
    private String courseName;
    private String courseCode;
    private Teacher[] teachers;
    private Student[] students;

    public Course(String courseName) {
        this.courseName = courseName;
    }

    public Course(String courseName, String courseCode, Teacher[] teachers, Student[] students) {
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.teachers = teachers;
        this.students = students;
    }
    public String getCourseName() {
        return courseName;
    }
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    public String getCourseCode() {
        return courseCode;
    }
    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }
    public Teacher[] getTeachers() {
        return teachers;
    }
    public void setTeachers(Teacher[] teachers) {
        this.teachers = teachers;
    }
    public Student[] getStudents() {
        return students;
    }
    public void setStudents(Student[] students) {
        this.students = students;
    }
    public String toString() {
        return "Course{" +
                "courseName='" + courseName + '\'' +
                ", courseCode='" + courseCode + '\'' +
                '}';
    }
    public static void printSchedule(Course course) {
        System.out.println("Schedule:");
        System.out.println("Day\tPeriod\tCourse Name\tCourse Code");
        ISchedule schedule = Schedule.getInstance();
        for (String day : schedule.getDays()) {
            for (int period : schedule.getPeriods()) {
                if (period != schedule.getBreakPeriod()) {
                    System.out.println(day + "\t" + period + "\t" + course.courseName+ "\t\t" + course.courseCode);
                } else {
                    System.out.println(day + "\t" + period + "\tBreak");
                }
            }
        }
    }
}


