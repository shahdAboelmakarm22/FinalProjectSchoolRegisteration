package com.example.schoolregisterationproject;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.fxml.FXML;
//import javafx. scene. control. ButtonBase;

//import java.awt.event.MouseEvent;
import java.io.IOException;

import javafx.scene.control.TextField;

import javafx.scene.Node;

public class StudentHomeController {
    @FXML
    TextField LEVELlABEL;
    @FXML
    TextField idlabel;
    @FXML
     Button GPAbtn;
    @FXML
      Button Managebtn;
    @FXML
    Button updatebtn;
    @FXML
            Button printbtn;
    Student student;

    public void setID(Student student) {
        this.student = student;
        LEVELlABEL.setText(String.valueOf(student.getStudentId()));
    }
    public void setLevel(Student student) {
        this.student = student;
        idlabel.setText(String.valueOf(student.getLevel()));
    }

    public void GoToStudentGpa(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("StudentGpa.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
        stage.setTitle("Student Gpa form");
        stage.show();
    }
    public void GoToStudentMangment(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("StudentMangCourse.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
        stage.setTitle("Student Mang Course form");
        stage.show();
    }
    /*@FXML
    private void handleUpdateInfoAction(ActionEvent event) {

        // Check if the student and enrollment objects are initialized
        student.updateinformation();
    }*/
    public void GoToStudentUpdateInfo(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("StudentUpdate.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
        stage.setTitle("Student info update form");
        stage.show();
    }
}
