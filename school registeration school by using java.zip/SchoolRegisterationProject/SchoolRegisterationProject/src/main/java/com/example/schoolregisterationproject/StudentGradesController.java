package com.example.schoolregisterationproject;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import javafx.fxml.FXML;

import javax.swing.text.Document;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class StudentGradesController {
    @FXML
    private TextField idfield;
    @FXML
    private TextField gpafield;

}