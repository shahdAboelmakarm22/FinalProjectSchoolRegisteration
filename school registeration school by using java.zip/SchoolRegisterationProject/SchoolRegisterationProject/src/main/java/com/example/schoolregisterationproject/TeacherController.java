package com.example.schoolregisterationproject;

public class TeacherController {
}
