package com.example.schoolregisterationproject;
import java.util.ArrayList;
import java.util.List;

public class Enrollment {
    private Student []students;
    private static List<Course> courses = new ArrayList<>();
    private ArrayList <String> enrolledcourses;
    public ArrayList<String> getEnrollcourses() {
        return enrolledcourses;
    }
    public void setEnrollcourses(ArrayList<String> enrollcourses) {
        this.enrolledcourses = enrollcourses;
    }
    public static void enrollCourse(Student student, Course course) {
        if (Student.isEnrolledInCourse(course,student)) {
            courses.add(course);
            System.out.println(student.getFirstName()+ " enrolled in " + course.getCourseName());
        }
        else {
            System.out.println(student.getFirstName() + " is already enrolled in " + course.getCourseName());
        }
    }
    public static void enrollCourse(List<Student> students, Course course) {
        for (Student student : students) {
            if (Student.isEnrolledInCourse(course, student)) {
                courses.add(course);
                System.out.println(student.getFirstName() + " enrolled in " + course.getCourseName());
            } else {
                System.out.println(student.getFirstName() + " is already enrolled in " + course.getCourseName());
            }
        }
    }
    public static void withdrawCourse(Student student, Course course) {
        if (courses.contains(course)) {
            courses.remove(course);
            System.out.println(student.getFirstName()+ " withdrew from the course: " + course.getCourseName());
        }
        else {
            System.out.println(student.getFirstName()+ " is not enrolled in the course: " + course.getCourseName());
        }
    }
    public static void withdrawCourse(List<Student> students, Course course) {
        for (Student student : students) {
            if (courses.contains(course)) {
                courses.remove(course);
                System.out.println(student.getFirstName() + " withdrew from the course: " + course.getCourseName());
            } else {
                System.out.println(student.getFirstName() + " is not enrolled in the course: " + course.getCourseName());
            }
        }
    }

}
