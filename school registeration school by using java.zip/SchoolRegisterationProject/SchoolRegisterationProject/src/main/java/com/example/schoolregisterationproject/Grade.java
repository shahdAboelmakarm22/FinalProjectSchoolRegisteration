package com.example.schoolregisterationproject;
import java.util.*;
public class Grade {
    private Student student;
    private Course course;
    private String grade;
    private int credits;
    public Grade(Student student, Course course, String grade, int credits) {
        this.student = student;
        this.course = course;
        this.grade = grade;
        this.credits = credits;
    }
    // Method to calculate GPA
    public Course getCourse() {
        return course;
    }
    public void setCourse(Course course) {
        this.course = course;
    }
    public String getGrade() {
        return grade;
    }
    public void setGrade(String grade) {
        this.grade = grade;
    }
    public  static double totalcalculateGPA(Student student) {
        double totalGradePoints = 0;
        int totalCredits = 0;
        for (Grade grade : student.getGrades()) {
            totalGradePoints += grade.getGradePoints() * student.getCredithours();
            totalCredits += student.getCredithours();
        }
        // Avoid division by zero
        if (totalCredits == 0) {
            return 0.0;
        }
        // Calculate GPA
        return totalGradePoints / totalCredits;
    }
    public double getGradePoints() {
        // Implement your grade-to-points conversion logic here
        // For simplicity, let's assume a basic conversion where A=4, B=3, C=2, D=1, F=0
        switch (grade) {
            case "A":
                return 4.0;
            case "B":
                return 3.0;
            case "C":
                return 2.0;
            case "D":
                return 1.0;
            default:
                return 0.0; // F or any other grade
        }
    }
}

