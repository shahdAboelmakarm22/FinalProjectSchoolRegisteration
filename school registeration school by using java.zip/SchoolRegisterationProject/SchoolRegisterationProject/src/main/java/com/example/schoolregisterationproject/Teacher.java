package com.example.schoolregisterationproject;
public class Teacher extends Person {
    private Student[]students;
    private boolean[] attendance;
    private Course course;
    private int TeacherId;
    private  int numStudents;
    public Teacher(String firstName, String lastName, String email, String phoneNumber, String address, String level,String password) {
        super(firstName, lastName, email, phoneNumber, address, level,password);
    }
    public Teacher(Student[] students, boolean[] attendance, String nameStudent, Course course, int teacherId, int numStudents) {
        try {
            this.students = new Student[numStudents];
            this.attendance = new boolean[numStudents];
            this.course = course;
        } catch (NegativeArraySizeException e) {
            System.out.println("Error creating Teacher object: Maximum number of students must be a non-negative value.");
        } catch (NullPointerException e) {
            System.out.println("Error creating Teacher object: Course cannot be null.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error creating Teacher object: Invalid teacher ID.");
        }

    }
    public void addStudentAndUpdateCount(Student student, Course course) {
        try {
            // Check if the students array is full
            if (numStudents >= students.length) {
                throw new ArrayIndexOutOfBoundsException("Maximum number of students reached.");
            }

            // Check if the student is already enrolled in the course
            if (Student.isEnrolledInCourse(course,student)) {
                System.out.println(student.getFirstName() + " is already enrolled in " + course.getCourseName());
                return;
            }

            // Add the student to the next available index
            students[numStudents] = student;
            numStudents++;
            // Enroll the student in the course
            Enrollment.enrollCourse(student,course);
            System.out.println("Student added successfully to the course: " + course.getCourseName());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        }
    }
    // Method to mark attendance of a student in a course
    public void markAttendance(Student student, Course course, boolean present) {
        try {
            for (int i = 0; i < students.length; i++) {
                if (students[i].equals(student) && this.course.equals(course)) {
                    attendance[i] = present;
                    return;
                }
            }
            throw new IllegalArgumentException("Student not found in the class or course mismatch.");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
    // Method to get the attendance of a student in a course
    public boolean getAttendance(Student student, Course course) {
        try {
            for (int i = 0; i < students.length; i++) {
                if (students[i].equals(student) && this.course.equals(course)) {
                    return attendance[i];
                }
            }
            throw new IllegalArgumentException("Student not found in the class or course mismatch.");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
    public void updateinformation(String firstName, String lastName, String email, String phoneNumber, String address) {
        try {
            if (firstName == null || firstName.isEmpty()) {
                throw new IllegalArgumentException("firstName cannot be null or empty");
            }
            setFirstName(firstName);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (lastName == null || lastName.isEmpty()) {
                throw new IllegalArgumentException("lastName cannot be null or empty");
            }
            setLastName(lastName);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (email == null || email.isEmpty()) {
                throw new IllegalArgumentException("email cannot be null or empty");
            }
            setEmail(email);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (phoneNumber == null || phoneNumber.isEmpty()) {
                throw new IllegalArgumentException("phoneNumber cannot be null or empty");
            }
            setPhoneNumber(phoneNumber);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        try {
            if (address == null || address.isEmpty()) {
                throw new IllegalArgumentException("address cannot be null or empty");
            }
            setAddress(address);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
    }
    public String getRole(String level) {
        if (level == null || level.isEmpty()) {
            throw new IllegalArgumentException("level cannot be null or empty");
        }
        if (level.equals("elementary")) {
            return "Elementary School Teacher";
        }
        else if (level.equals("middle"))
        {
            return "Middle School Teacher";
        }
        else if (level.equals("high"))
        {
            return "High School Teacher";
        }
        else
        {
            return null;
        }
    }
    public String toString() {
        if (course != null) { // Check if course is not null before accessing its methods
            return "Teacher{" +
                    "name='" + getFirstName() + '\'' +
                    ", course='" + course.getCourseName()+ '\'' +
                    ", teacherId=" + TeacherId +
                    '}';
        } else {
            return "Teacher{" +
                    "name='" + getFirstName() + '\'' +
                    ", course='Course not assigned'" + // Provide a default value if course is null
                    ", teacherId=" + TeacherId +
                    '}';
        }
    }
    public void printStudentList() {
        System.out.println("Student List for " + course.getCourseName() + ":");
        System.out.printf("%-20s %-10s %-20s %-10s%n", "Name", "ID", "Course Name", "Course ID");
        for (Student student : students) {
            System.out.printf("%-20s %-10d %-20s %-10d%n", student.getFirstName(), student.getStudentId(), course.getCourseName(), course.getCourseCode());
        }
    }
    public void bookTicket(int TeacherId, Transportation transportation) {
        if (transportation.isTicket()) {
            System.out.println("Ticket already booked for transportation of Teacher " + TeacherId + ".");
        } else {
            transportation.setTicket(true);
            System.out.println("Ticket booked successfully for transportation of Teacher " + TeacherId + ".");
        }
    }
}



