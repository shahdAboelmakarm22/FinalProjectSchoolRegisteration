package com.example.schoolregisterationproject;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class TeacherPage {

    @FXML
    Button buttonclick;


}
