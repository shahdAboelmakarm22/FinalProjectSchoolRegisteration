package com.example.schoolregisterationproject;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.fxml.FXML;
//import javafx. scene. control. ButtonBase;

//import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javafx.scene.control.TextField;

import javafx.scene.Node;
import org.bson.Document;

public class StudentMangController {
    @FXML
    Button addbtn;
    @FXML
    private TextField idfield;
    @FXML
    private TextField coursefield;
    Enrollment enrollment;
    Student student;
    Course course;
    List<Course> courses = new ArrayList<>();
    /*public StudentMangController(Enrollment enrollment, Student student) {
        this.enrollment = enrollment;
        this.student = student;
    }*/

    public void setStudent(Student student) {
        this.student = student;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public Student getStudent() {
        return student;
    }

    public Course getCourse() {
        return course;
    }

    @FXML
    private void handleManagmentCourseAction(ActionEvent event) {
        // Check if the student and enrollment objects are initialized
        if (student == null || enrollment == null) {
            // Display an error message or handle the error condition
            return;
        }
        // Create a new Course object
        Course newCourse = new Course("New Course"); // You can replace "New Course" with the desired course name
        // Call the enrollCourse method to add the course to the student's enrollment
        Enrollment.enrollCourse(student, newCourse);
        // Add the course to the courses list
        courses.add(newCourse);
    }
    public void addCourse(ActionEvent event){
        Document userData = MongoDbConnection.loadstudent(idfield.getText());
        if(userData != null && Objects.equals(userData.getString("email"), idfield.getText())){
            List<String> courses = userData.get("Courses", List.class);
            if(courses == null) {
                courses = new ArrayList<>();
            }
            courses.add(coursefield.getText());
            userData.put("Courses", courses);
            MongoDbConnection.updateStudent(idfield.getText(), userData);
        }
    }
    public void deleteCourse(ActionEvent event){
        Document userData = MongoDbConnection.loadstudent(idfield.getText());
        if(userData != null && Objects.equals(userData.getString("email"), idfield.getText())){
            List<String> courses = userData.get("Courses", List.class);
            if(courses != null) {
                courses.remove(coursefield.getText());
                userData.put("Courses", courses);
                MongoDbConnection.updateStudent(idfield.getText(), userData);
            }
        }
    }
}
